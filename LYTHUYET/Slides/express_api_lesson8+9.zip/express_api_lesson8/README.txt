Đây là project mẫu cho buổi học lý thuyết số 8
Các nội dung trong buổi học gồm có
    - refactor lại source code theo hướng sử dụng Router và MVC 
    - bổ sung bcrypt để mã hóa/giải mã mật khẩu 
    - sử dụng jwt để xác thực người dùng 
    - giới thiệu thêm về refresh token
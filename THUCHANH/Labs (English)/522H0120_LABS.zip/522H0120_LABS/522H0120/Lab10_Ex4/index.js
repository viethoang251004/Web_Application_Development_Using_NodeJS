const express = require('express');
const socketio = require('socket.io');
const multer = require('multer');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 8080;

// Setup static folder for frontend
app.use(express.static('public'));

// Setup file upload
const storage = multer.diskStorage({
    destination: './public/uploads/',
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}_${file.originalname}`);
    },
});
const upload = multer({ storage });

// API for image upload
app.post('/upload', upload.single('image'), (req, res) => {
    const filePath = `/uploads/${req.file.filename}`;
    res.json({ filePath });
});

// Start server
const server = app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
const io = socketio(server);

// Socket.IO setup
io.on('connection', (socket) => {
    console.log(`Client connected: ${socket.id}`);

    // Handle message sending
    socket.on('send-message', (data) => {
        io.emit('receive-message', data); // Broadcast message to all clients
    });

    // Handle image sending
    socket.on('send-image', (data) => {
        io.emit('receive-image', data); // Broadcast image to all clients
    });

    socket.on('disconnect', () => {
        console.log(`Client disconnected: ${socket.id}`);
    });
});

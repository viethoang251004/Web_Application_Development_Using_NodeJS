const express = require('express');
const bodyParser = require('body-parser')
const multer = require('multer')
const emailValidator = require('email-validator')
const app = express();


const upload = multer({
    dest: 'uploads',
    fileFilter: (req, file, callback) => {

        if (file.mimetype.startsWith('/image')) {
            callback(null, true)//cho phep upload
        }
        else callback(null, false) // khong cho upload loai file khac anh
    }, limits: { fileSize: 500000 }
}) // 500kb max
app.set('view engine', 'ejs')

/*
    form body có nhiều định dạng khác nhau
    hiện tại html đang gửi dữ liệu theo dạng thông thường
    mà dạng thông thường tức là url-encoded nên
    ta đang cấu hình để bodyParser xử lý nội dung dạng url-encoded
*/
app.use(bodyParser.urlencoded({ extended: false }))

app.get('/', (req, res) => {
    res.render('index')
})

app.get('/add', (req, res) => {
    res.render('add')
})

app.post('/add', (req, res) => {
    let uploader = upload.single('image')
    uploader(req, res, err => {
        let product = req.body
        let image = req.file

        // check error first
        if (err) {
            res.end('Image too large')
        }
        else if (!image) {
            res.end('No image or invalid image')
        }

        else res.end('Xu ly POST them san pham')
    })
})

app.get('/login', (req, res) => {
    // ở đây cùng cần email và password dạng rỗng
    res.render('login', { email: '', password: '' }) // không có phần mở rộng
})

app.post('/login', (req, res) => {
    let acc = req.body
    let error = ''
    if (!acc.email) {
        error = 'Vui lòng nhập email'
    }
    else if (!emailValidator.validate(acc.email)) {
        error = 'Email không đúng định dạng'
    }
    else if (!acc.password) {
        error = 'Vui lòng nhập mật khẩu'
    }
    else if (acc.password.length < 6) {
        error = 'Mật khẩu phải có từ 6 ký tự'
    }
    else if (acc.email !== 'admin@gmail.com' || acc.password != '123456') {
        error = 'Sai email hoặc mật khẩu'
    }

    if (error.length > 0) {
        res.render('login', {
            errorMessage: error,
            email: acc.email,
            password: acc.password
        })
    } else {
        res.set('Content-Type', 'text/html')
        res.end('Đăng nhập thành công')
    }
})

app.use((req, res) => {
    res.end('Content-Type', 'text/html') // lưu và không cần chạy lại npm start
    res.end('Liên kết này không được hỗ trợ')
})

app.listen(8080, () => console.log('http://localhost:8080'))

const https = require('https')

const options = {
    hostname: 'web-nang-cao.hoang.com',
    path: '/lab5/users',
    port: 443,
    method: 'GET'
}

const request = https.request(options, res => {
    let body = ''
    res.on('data', d => body += d.toString())
    res.on('end', () => {
        console.log(JSON.parse(body))
    })
    res.on('error', e => console.log(e))
})

request.on('error', e => console.log(e))
request.end()
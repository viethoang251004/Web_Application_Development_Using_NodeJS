const express = require('express');
const bodyParser = require('body-parser')
const multer = require('multer')
const emailValidator = require('email-validator')
const fs = require('fs')
const uuid = require('short-uuid');
const session = require('express-session')
require('dotenv').config()
const rateLimit = require('express-rate-limit');

// Apply rate limiting to all routes
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per windowMs
    message: 'Too many requests from this IP, please try again after 15 minutes.'
});

// app.use(limiter);

const app = express();
let productList = new Map()

const upload = multer({
    dest: 'uploads',
    fileFilter: (req, file, callback) => {

        if (file.mimetype.startsWith('image/')) {
            callback(null, true)//cho phep upload
        }
        else callback(null, false) // khong cho upload loai file khac anh
    }, limits: { fileSize: 500000 }
}) // 500kb max

app.set('view engine', 'ejs')
app.use('/uploads', express.static('uploads'))
app.use(session({ secret: 'secret_password_here' }))
app.use(limiter);

/*
    form body có nhiều định dạng khác nhau
    hiện tại html đang gửi dữ liệu theo dạng thông thường
    mà dạng thông thường tức là url-encoded nên
    ta đang cấu hình để bodyParser xử lý nội dung dạng url-encoded
*/
app.use(bodyParser.urlencoded({ extended: false }))

app.get('/', (req, res) => {
    // nếu chưa đăng nhập chuyển hướng tới /login
    // kiểm tra xemn session có chứa biến user hay không
    if (!req.session.user) {
        res.redirect('/login')
    }
    // truyền productList vào trang chủ để hiển thị trong trang chủ
    else res.render('index', { products: Array.from(productList.values()) })
})

app.get('/product/:id', (req, res) => {
    let id = req.params.id
    let product = productList.get(id)
    res.render('product', { product })
})

app.get('/add', (req, res) => {
    // khi moi load trang /add thi form can thong tin ban dau la rong, nen van phai truyen bien rong qua
    res.render('add', { error: '', name: '', price: '', desc: '' })
})

app.post('/add', (req, res) => {
    let uploader = upload.single('image')
    uploader(req, res, err => {
        let { name, price, desc } = req.body
        let image = req.file

        let error = undefined

        if (!name || name.length === 0) {
            error = 'Vui lòng nhập tên hợp lệ!'
        }
        else if (!price || price.length === 0) {
            error = 'Vui lòng nhập giá hợp lệ!'
        }
        else if (isNaN(price) || parseInt(price) < 0) {
            error = 'Giá không hợp lệ!'
        }
        else if (!desc || desc.length === 0) {
            error = 'Vui lòng nhập mô tả sản phẩm!'
        }
        else if (err) {
            error = 'Ảnh quá lớn!'
        }
        else if (!image) {
            error = 'Chưa có ảnh hoặc ảnh không hợp lệ!'
        }

        if (error) {
            //{error, name, price, desc} la viet tat cua {error:error, name:name, price:price, desc:desc}
            res.render('add', { error, name, price, desc })
        }
        else {
            let imagePath = `uploads/${image.originalname}`
            fs.renameSync(image.path, imagePath)

            let product = {
                id: uuid.generate(),
                name: name,
                price: parseInt(price),
                desc: desc,
                image: imagePath
            }

            //them san pham vao danh sach
            productList.set(product.id, product)
            res.redirect('/') //quay lai trang chu
        }
    })
})

app.get('/login', (req, res) => {
    // nếu đã đăng nhập thì không cần login nữa
    if (req.session.user) {
        res.redirect('/') //về trang chủ
    }
    //email và password dạng rỗng
    else res.render('login', { email: '', password: '' }) // không có phần mở rộng
})

app.post('/login', (req, res) => {
    let acc = req.body
    let error = ''
    if (!acc.email) {
        error = 'Vui lòng nhập email!'
    }
    else if (!emailValidator.validate(acc.email)) {
        error = 'Email không đúng định dạng!'
    }
    else if (!acc.password) {
        error = 'Vui lòng nhập mật khẩu!'
    }
    else if (acc.password.length < 6) {
        error = 'Mật khẩu phải có từ 6 ký tự!'
    }
    else if (acc.email !== process.env.EMAIL || acc.password != process.env.PASSWORD) {
        error = 'Sai email hoặc mật khẩu!'
    }

    if (error.length > 0) {
        res.render('login', {
            errorMessage: error,
            email: acc.email,
            password: acc.password
        })
    } else {
        // nếu đăng nhập thành công thì phải ghi nhận vào
        //session thông qua biến user
        req.session.user = acc.email
        res.set('Content-Type', 'text/html')
        res.redirect('/')
    }
})

// app.use((req, res) => {
//     res.end('Content-Type', 'text/html') // lưu và không cần chạy lại npm start
//     res.end('Liên kết này không được hỗ trợ')
// })

app.post('/delete', (req, res) => {
    let { id } = req.body
    if (!id) {
        // Không cần stringify
        res.json({ code: 1, message: 'Mã sản phẩm không hợp lệ!' })
    }
    else if (!productList.has(id)) {
        res.json({ code: 2, message: 'Không tìm thấy sản phẩm nào!' })
    }
    else {
        let p = productList.get(id)
        productList.delete(id)
        res.json({
            code: 0, message: 'Đã xóa sản phẩm thành công!',
            data: p
        })
    }
})

app.get('/product/:id', (req, res) => {
    const { id } = req.params;
    const product = productList.get(id);

    if (!product) {
        return res.status(404).send('Không tìm thấy sản phẩm!');
    }

    res.render('product', {
        product: product
    });
});

app.use((req, res) => {
    res.status(404).send('Liên kết này không được hỗ trợ');
});

// nếu chưa có port trong env thì dùng 8080
let port = process.env.PORT || 8080

app.listen(port, () => console.log('http://localhost:' + port))

function closeNotification() {
    document.getElementById('notification').classList.remove('show');
}
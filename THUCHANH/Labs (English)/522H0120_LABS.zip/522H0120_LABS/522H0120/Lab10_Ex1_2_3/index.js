require('dotenv').config()
const { name } = require('ejs')
const express = require('express')
const socketio = require('socket.io')

const app = express()
app.set('view engine', 'ejs')

app.get('/', (req, res) => {
    res.render('home')
})

app.get('/login', (req, res) => {
    res.render('login')
})

app.get('/chat', (req, res) => {
    res.render('chat')
})

const PORT = process.env.PORT || 8080
const httpServer = app.listen(PORT, () => console.log('http://localhost:' + PORT))
const io = socketio(httpServer)

io.on('connection', client => {
    console.log(`Client ${client.id} đã kết nối`)

    client.free = true
    client.loginAt = new Date().toLocaleTimeString() // khoi tao thoi gian luc ket noi


    client.on('disconnect', () => {

        console.log(`\t\t${client.id} đã thoát`)

        //thong bao cho tat ca cac user con lai truoc khi minh thoat
        client.broadcast.emit('user-leave', client.id)
    })

    client.on('register-name', username => {
        client.username = username

        // gui thong tin dang ky cho ten cho cac user con lai
        client.broadcast.emit('register-name', {
            id: client.id,
            username: username
        })
    })

    // gui danh sach user dang online cho nguoi moi, cap nhat lien tuc
    // phai dung username thong nhat toan bo code
    client.emit('list-users', Array.from(io.sockets.sockets.values()).map(socket => ({
        id: socket.id,
        username: socket.username, // chuyen tu name thanh username
        free: socket.free,
        loginAt: socket.loginAt 
    })))

    // gui thong tin nguoi moi cho tat ca nhung nguoi truoc do
    // doi lai dung 'username' het cho thong nhat
    client.broadcast.emit('new-user', {
        id: client.id,
        username: client.username,
        free: client.free,
        loginAt: client.loginAt
    })
})
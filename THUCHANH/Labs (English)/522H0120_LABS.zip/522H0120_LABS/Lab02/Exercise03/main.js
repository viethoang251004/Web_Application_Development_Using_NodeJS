//Giả sử có 5 url khác nhau như sau, trong đó có 3 url đầu tiên chứa mã sinh viên hợp lệ với định dạng là /students/{id} hoặc /students/{id}/


let url1 = '/students/123x'
let url2 = '/students/123x/'
let url3 = '/students/123x///' // không hợp lệ
let url4 = '/students/123x/abc'
let url5 = '/students/' // không hợp lệ

// pattern dùng để kiểm tra bằng regular expression
let pattern = /\/students\/[a-zA-Z0-9]+\/*$/ig

// Bước 1. In xem có bao nhiêu url thỏa mãn với pattern
// console.log(url1.match(pattern));
// console.log(url2.match(pattern));
// console.log(url3.match(pattern));
// console.log(url4.match(pattern));
// console.log(url5.match(pattern));

/* 
    Như vậy là có 3 url đầu tiên hợp lệ,
    bây giờ chúng ta sẽ tách 3 url đầu tiên để lấy ra id của sinh viên bên trong nó
*/

let IdPattern = /[a-zA-Z0-9]+\/*$/ig

// lúc này chỉ còn 3 url đầu tiên hợp lệ nên chỉ dùng 3 url đầu tiên
// console.log(url1.match(IdPattern)[0]);
// console.log(url2.match(IdPattern)[0]);
// console.log(url3.match(IdPattern)[0]);

// Bước 3. Xóa các dấu gạch cuối cùng dư thừa
console.log(url1.match(IdPattern)[0].replace(/\/*$/ig, ''));
console.log(url2.match(IdPattern)[0].replace(/\/*$/ig, ''));
console.log(url3.match(IdPattern)[0].replace(/\/*$/ig, ''));


// như vậy là đã tách được id của sinh viên từ path
// bây giờ sẽ áp dụng đề mạng vào API